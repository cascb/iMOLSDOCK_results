BS_BB - Best sampled structures for backbone RMSD
BS_LE_AA - Best sampled and Top-ranked (Lowest Energy - LE) structures with All-atom RMSD
